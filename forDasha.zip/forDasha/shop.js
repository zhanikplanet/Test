document.addEventListener("DOMContentLoaded", function () {
    showLoadingSpinner();
    setTimeout(hideLoadingSpinner, 2500);

    const buyButtons = document.querySelectorAll('.chocolate-card-footer button');

    buyButtons.forEach(button => {
        button.addEventListener('click', function () {
            const card = this.closest('.chocolate-card');
            const name = document.querySelector(".name").textContent;
            console.log(name)
            const description = card.querySelector('.description').textContent;
            console.log(description)
            const price = card.querySelector('.price').textContent;
            console.log(price)

            const chocolate = {
                name: name,
                description: description,
                price: price
            };

            let shoppingList = localStorage.getItem('shoppingList');
            if (!shoppingList) {
                shoppingList = [];
            } else {
                shoppingList = JSON.parse(shoppingList);
            }

            shoppingList.push(chocolate);

            localStorage.setItem('shoppingList', JSON.stringify(shoppingList));


            if (confirm("Do you want to continue shopping?")) {
                window.location.href = 'shopping_list.html';
            }
        });
    });
});

function HamburgerMenu() {
    const mylinks = document.querySelector(".navigation-links");
    if (mylinks.style.display === "block") {
        mylinks.style.display = "none";
    } else {
        mylinks.style.display = "block";
    }
}

function showLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'block';
}

function hideLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'none';
}
